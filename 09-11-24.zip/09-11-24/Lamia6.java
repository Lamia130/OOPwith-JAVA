import java.util.Scanner;
public class Lamia6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
String str1,str2;
float num1,num2;
System.out.println("Enter two floating-point numbers: ");
str1=ScanMe.nextLine();
str2=ScanMe.nextLine();
num1=Float.parseFloat(str1);
num2=Float.parseFloat(str2);
num1=Math.round(num1*1000.0f)/1000.0f;
num2=Math.round(num2*1000.0f)/1000.0f;
if(num1==num2)
{
	System.out.println("They are the same");
}
else
{
	System.out.println("They are not the same");
}
ScanMe.close();
	}

}
