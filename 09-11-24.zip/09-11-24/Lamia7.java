import java.util.Scanner;
public class Lamia7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
String mon;
System.out.println("Enter the name of the month whose total days you are wanting to know (Capitalize first letter and write the full name of the month): ");
mon=ScanMe.nextLine();
if(mon.equals("September")||mon.equals("April")||mon.equals("June")||mon.equals("November"))
{
	System.out.println("30 days");
}
else if(mon.equals("January")||mon.equals("March")||mon.equals("May")||mon.equals("July")||mon.equals("August")||mon.equals("October")||mon.equals("December"))
{
	System.out.println("31 days");
}
else if(mon.equals("February"))
{
	System.out.println("28 days (29 days on leap years)");
}
ScanMe.close();
	}

}
