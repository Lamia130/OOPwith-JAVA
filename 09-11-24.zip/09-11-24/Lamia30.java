import java.util.Scanner;
public class Lamia30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int num1,num2,num3;
System.out.println("Enter three numbers: ");
num1=ScanMe.nextInt();
num2=ScanMe.nextInt();
num3=ScanMe.nextInt();
if(num1>num2&&num2>num3)
{
	System.out.println("decreasing");
}
else if(num3>num2&&num2>num1)
{
	System.out.println("increasing");
}
else
{
	System.out.println("Neither increasing or decreasing order");
}
ScanMe.close();
	}

}
