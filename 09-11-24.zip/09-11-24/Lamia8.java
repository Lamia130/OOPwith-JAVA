import java.util.Scanner;
public class Lamia8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
String ch;
int len;
System.out.println("Enter a single character from the alphabet: ");
ch=ScanMe.nextLine();
len=ch.length();
if(ch.equalsIgnoreCase("a")||ch.equalsIgnoreCase("e")||ch.equalsIgnoreCase("i")||ch.equalsIgnoreCase("o")||ch.equalsIgnoreCase("u"))
{
	System.out.println("Vowel");
}
else if(ch.equalsIgnoreCase("b")||ch.equalsIgnoreCase("c")||ch.equalsIgnoreCase("d")||ch.equalsIgnoreCase("f")||ch.equalsIgnoreCase("g")||ch.equalsIgnoreCase("h")||ch.equalsIgnoreCase("j")||ch.equalsIgnoreCase("k")||ch.equalsIgnoreCase("l")||ch.equalsIgnoreCase("m")||ch.equalsIgnoreCase("n")||ch.equalsIgnoreCase("p")||ch.equalsIgnoreCase("q")||ch.equalsIgnoreCase("r")||ch.equalsIgnoreCase("s")||ch.equalsIgnoreCase("t")||ch.equalsIgnoreCase("v")||ch.equalsIgnoreCase("w")||ch.equalsIgnoreCase("x")||ch.equalsIgnoreCase("y")||ch.equalsIgnoreCase("z"))
{
	System.out.println("Consonant");
}
else if(len>1)
{
	System.out.println("Invalid input");
}
else
{
	System.out.println("Invalid input");
}
ScanMe.close();
	}

}
