import java.util.Scanner;
public class Lamia11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int n,i,sum=0;
System.out.println("Enter the n-th term of the natural numbers to find out their sum: ");
n=ScanMe.nextInt();
for(i=1;i<=n;i++)
{
	System.out.printf("%d ",i);
	sum=sum+i;
}
System.out.println("\n"+sum);
ScanMe.close();
	}

}
