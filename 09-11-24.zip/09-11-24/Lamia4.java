import java.util.Scanner;
public class Lamia4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
float n,m;
System.out.println("Enter a floating-point number: ");
n=ScanMe.nextFloat();
m=Math.abs(n);
if(n==0)
{
	System.out.println("zero");
}
else if(n>0)
{
	System.out.print("positive");
}
else if(n<0)
{
	System.out.print("negative");
}
if(m<1&&n!=0)
{
	System.out.println(" small");
}
else if(n>1000000)
{
	System.out.println(" large");
}
ScanMe.close();
	}

}
