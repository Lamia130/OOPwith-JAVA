import java.util.Scanner;
public class Lamia21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int i,j,k,l,m,o,p,n,r;
System.out.println("How many odd rows? Say it - ");
r=ScanMe.nextInt();
n=(r+1)/2;//2x-1=7; x= r+1/2 
for(i=1;i<=n;i++)
{
	for(j=1;j<=n-i;j++)
	{
		System.out.print(" ");
	}
	for(k=1;k<=i;k++)
	{
		System.out.print("*");
	}
	for(l=2;l<=i;l++)
	{
		System.out.print("*");
	}
	System.out.println();
}
for(i=1;i<=n-1;i++)
{
	for(m=1;m<=i;m++)
	{
		System.out.print(" ");
	}
	for(o=n-1;o>=i;o--)
	{
		System.out.print("*");
	}
	for(p=n-2;p>=i;p--)
	{
		System.out.print("*");
	}
	System.out.println();
}
ScanMe.close();
	}

}
