import java.util.Scanner;
public class Lamia1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int n;
System.out.println("Enter a number to check if it's positive or negative: ");
n=ScanMe.nextInt();
if(n>0)
{
	System.out.println("Positive");
}
else if(n<0)
{
	System.out.println("Negative");
}
ScanMe.close();
	}

}
