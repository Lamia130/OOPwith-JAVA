import java.util.Scanner;
public class Lamia27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int n;
System.out.println("Enter an integer: ");
n=ScanMe.nextInt();
if(n>0)
{
	System.out.println("positive");
}
else if(n<0)
{
	System.out.println("negative");
}
else if(n==0)
{
	System.out.println("zero");
}
ScanMe.close();
	}

}
