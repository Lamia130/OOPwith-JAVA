import java.util.Scanner;
public class Lamia15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int n,i,sum=0;
System.out.println("Enter the n-th odd number: ");
n=ScanMe.nextInt();
for(i=0;i<n;i=i+2)
{
	sum=sum+i+1;
}
System.out.println("The summation is: "+sum);
ScanMe.close();
	}

}
