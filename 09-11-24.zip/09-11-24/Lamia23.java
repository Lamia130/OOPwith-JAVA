import java.util.Scanner;
public class Lamia23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int i,j,k,l,n;
System.out.println("How many rows do you want in your triangle? Say it - ");
n=ScanMe.nextInt();
for(i=1;i<=n;i++)
{
	for(j=n-i;j>=1;j--)
	{
		System.out.print(" ");
	}
	for(k=1;k<=i;k++)
	{
		System.out.print("*");
	}
	for(l=2;l<=i;l++)
	{
		System.out.print("*");
	}
	System.out.println();
}
ScanMe.close();
	}

}
