import java.util.Scanner;
import java.util.Random;
public class Lamia5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
Random Anything=new Random();
int n,x;
System.out.println("Enter any number: ");
n=ScanMe.nextInt();
x=Anything.nextInt(7)+1;
System.out.println(x);
switch(x)
{
case 1:System.out.println("Saturday");
break;
case 2:System.out.println("Sunday");
break;
case 3:System.out.println("Monday");
break;
case 4:System.out.println("Tuesday");
break;
case 5:System.out.println("Wednesday");
break;
case 6:System.out.println("Thursday");
break;
case 7:System.out.println("Friday");
break;
default:System.out.println("\0");
}
ScanMe.close();
	}

}
