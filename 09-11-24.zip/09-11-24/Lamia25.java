import java.util.Scanner;
public class Lamia25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int i,j,k,l,n,num;
System.out.println("What number do you want to print in your rhombus? Say it - ");
num=ScanMe.nextInt();
System.out.println("How many rows do you want in your rhombus? Say it - ");
n=ScanMe.nextInt();
for(i=1;i<=n;i++)
{
	for(j=1;j<=n-i;j++)
	{
		System.out.print(" ");
	}
	for(k=i;k>=1;k--)
	{
		System.out.print(num);
	}
	for(l=n-i;l>=1;l--)
	{
		System.out.print(num);
	}
	System.out.println();
}
ScanMe.close();
	}

}
