import java.util.Scanner;
public class Lamia9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int year;
System.out.println("Enter a year to check whether it is a leap year or not: ");
year=ScanMe.nextInt();
if((year%4==0&&year%100!=0)||(year%400==0))
{
	System.out.println("Leap year");
}
else if(year%1==0)
{
	System.out.println("Not leap year");
}
ScanMe.close();
	}

}
