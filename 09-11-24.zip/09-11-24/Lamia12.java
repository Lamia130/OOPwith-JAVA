import java.util.Scanner;
public class Lamia12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int i;
float[] num=new float[6];
float sum=0,avg;
System.out.println("Enter 5 numbers: ");
for(i=1;i<=5;i++)
{
	num[i]=ScanMe.nextFloat();
	sum=sum+num[i];
}
avg=(float)sum/5;
System.out.println();
System.out.println("The summation is: "+sum);
System.out.println("The average is: "+avg);
ScanMe.close();
	}

}
