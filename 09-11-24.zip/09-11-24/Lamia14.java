import java.util.Scanner;
public class Lamia14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
System.out.println("Enter the number whose multiplication table you would like to see: ");
int n,i;
n=ScanMe.nextInt();
int[] ans=new int[10];
for(i=0;i<10;i++)
{
	ans[i]=n*(i+1);
	System.out.println(n+" * "+(i+1)+" = "+ans[i]);
}
ScanMe.close();
	}

}
