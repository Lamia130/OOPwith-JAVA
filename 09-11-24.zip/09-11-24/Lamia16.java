import java.util.Scanner;
public class Lamia16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int num,n,i,j;
System.out.println("Which number do you want to see printed? Say it - ");
num=ScanMe.nextInt();
System.out.println("How many rows do you want in the triangle? Say it - ");
n=ScanMe.nextInt();
for(i=0;i<n;i++)
{
	for(j=0;j<=i;j++)
	{
		System.out.print(num+" ");
	}
	System.out.println();
}
	}

}
