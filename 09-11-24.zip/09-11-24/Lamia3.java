import java.util.Scanner;
public class Lamia3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int num1,num2,max;
System.out.println("Enter three numbers to find out the greatest of them all: ");
max=ScanMe.nextInt();
num1=ScanMe.nextInt();
num2=ScanMe.nextInt();
if(num1>max)
{
	max=num1;
}
if(num2>max)
{
	max=num2;
}
System.out.println("The greatest number is: "+max);
ScanMe.close();
	}

}
