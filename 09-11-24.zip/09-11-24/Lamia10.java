public class Lamia10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i;
System.out.println("The first 10 natural numbers are -");
		for(i=1;i<=10;i++)
{
	System.out.printf("%d\n",i);
}
	}

}
