import java.util.Scanner;
public class Lamia19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int i,j,k,l,n;
System.out.println("How many rows do you want? Say it - ");
n=ScanMe.nextInt();
for(i=1;i<=n;i++)
{
	for(j=1;j<=n-i;j++)
	{
		System.out.print(" ");
	}
	for(k=1;k<=i;k++)
	{
		System.out.print(i);
	}
	for(l=2;l<=i;l++)
	{
		System.out.print(i);
	}
	System.out.println();
	
}
ScanMe.close();
	}

}
