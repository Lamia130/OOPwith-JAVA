import java.util.Scanner;
public class Lamia29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
long num;
int count;
String str;
System.out.println("Enter a number to see how many digits are there: ");
num=ScanMe.nextLong();
if(num>0&&num<10000000000L)
{
	str=Long.toString(num);
	count=str.length();
	System.out.println("There are "+count+" digit(s) in the number.");
}
ScanMe.close();
	}

}
