import java.util.Scanner;
public class Lamia20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int i,j,n,count=0;
System.out.println("How many rows do you want in the pyramid? Say it - ");
n=ScanMe.nextInt();
for(i=1;i<=n;i++)
{
	for(j=1;j<=i;j++)
	{
		count++;
		System.out.print(count);
	}
	System.out.println();
}
ScanMe.close();
	}

}
