import java.util.Scanner;
public class Lamia13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
int n,i;
System.out.println("Enter the n-th term: ");
n=ScanMe.nextInt();
int [] cub=new int[n];
for(i=0;i<n;i++)
{
	cub[i]=(int)Math.pow(i+1,3);
	System.out.printf("%d ",cub[i]);
}
ScanMe.close();
	}

}
