import java.util.Scanner;
public class Lamia2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ScanMe=new Scanner(System.in);
float a,b,c,d,e,x1,x2;
System.out.println("Enter the coefficients of the quadratic equation: ");
a=ScanMe.nextFloat();
b=ScanMe.nextFloat();
c=ScanMe.nextFloat();
d=(float)Math.pow(b,2)-4*a*c;
if(d>=0)
{
	e=(float)Math.sqrt(d);
	if(d>0)
	{
		x1=(-b+e)/(2*a);
		x2=(-b-e)/(2*a);
		System.out.println("The roots are - "+x1+" and "+x2);
	}
	else if(d==0)
	{
		x1=-b/(2*a);
		System.out.println("The root is - "+x1);
	}
}
else
{
	System.out.println("No real root available");
}
ScanMe.close();
	}

}
